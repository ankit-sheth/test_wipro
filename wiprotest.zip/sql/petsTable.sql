
/** you can create pets table in any database and change realted configuration in config/config.js file, i have used pgsql for this */
/** for now, not applied unique constraint for name, but can apply  //     CONSTRAINT unique_pet_name UNIQUE (name), code also applied with query checking for unique, but for disabled  **/


CREATE TABLE public.pets
(
    id bigint NOT NULL GENERATED ALWAYS AS IDENTITY ( INCREMENT 1 START 1 MINVALUE 1 MAXVALUE 9223372036854775807 CACHE 1 ),
    name character varying(50) COLLATE pg_catalog."default" NOT NULL,
    age integer,
    colour character varying(50) COLLATE pg_catalog."default",
    created_at timestamp with time zone DEFAULT CURRENT_DATE,
    updated_at timestamp with time zone DEFAULT CURRENT_DATE,
    CONSTRAINT primary_id PRIMARY KEY (id)
)