const sinon = require("sinon");
const expect  = require("chai").expect;
const request = require("request");
const uuid = require("uuid");

const petBO = require("../../bo/pet_bo");
const petDAO = require("../../dao/pet_dao");


describe("Pets Test", function(done) {
	const requestId = uuid.v1();

	const getDataResponse = [{"id":1, "name":"unittest-1", "age":20, "colour":"blue"}];
	const createDataResponse = 1;
	const updateDataResponse = {"id":1, "name":"unittest-1", "age":20, "colour":"blue"};
	const deleteDataResponse = true;

	////////////////////////////////////////////////////////////

	// Prepare sandbox
	var sandbox;

	before(function() {
		sandbox = sinon.createSandbox();
	});

	beforeEach(function () {

	});

	it("Get pets should return one data", function(done) {

		sandbox.stub(petDAO.prototype, "getAll").resolves(getDataResponse);

		let req = {};
		let res = {};
		new petBO()
			.getPets(requestId)
			.then((response) => {
				expect(response.length).to.equal(1);
				done();
			});
	});

	it("Create pets should return the last inserted id", function(done) {

		sandbox.stub(petDAO.prototype, "insert").resolves(createDataResponse);

		let req = {};
		let res = {};
		new petBO()
			.createPet(requestId)
			.then((response) => {
				expect(response).to.equal(1);
				done();
			});
	});

	it("Edit pets should return the updated record", function(done) {

		sandbox.stub(petDAO.prototype, "edit").resolves(updateDataResponse);

		let req = {};
		let res = {};
		new petBO()
			.editPet(requestId)
			.then((response) => {
				expect(response.id).to.equal(1);
				done();
			});
	});

	it("Delete pets should return the succes", function(done) {

		sandbox.stub(petDAO.prototype, "delete").resolves(deleteDataResponse);

		let req = {};
		let res = {};
		new petBO()
			.deletePet(requestId)
			.then((response) => {
				expect(response).to.equal(true);
				done();
			});
	});


	afterEach(function () {
		sandbox.restore();
	});


});