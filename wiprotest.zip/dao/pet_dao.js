/* @File : to write the pet table db queries */

// common files for each dao
const dbConnectionPool = require("../lib/db_connection");
const LoggerHelper = require("../helpers/logger_helper");
const constant = require("../helpers/constant");


function PetDAO() { }


/**
 * @Function : to get all types of pet
 * @param {*} requestId
 */
PetDAO.prototype.getAll = (requestId) => {
	new LoggerHelper().log("info", requestId);

	return new Promise(async (resolve, reject) => {
		try {
			var query = "SELECT * FROM pets ORDER BY created_at DESC";

			//retrieving a record from details
			dbConnectionPool.query(query, (err, result, fields) => {

				if (err) {
					new LoggerHelper().log("error", requestId, constant.DB_QUERY_ERROR, err);
					reject(err);
				}

				new LoggerHelper().log("info", requestId, constant.BEFORE_RETURNING_RESULT);
				resolve(result.rows);
			});

		} catch (error) {
			new LoggerHelper().log("error", requestId, constant.INSIDE_CATCH_BLOCK, error);
			reject(error);
		}
	}).catch(function(err) {
		return err;
	});
	
};

/**
 * @Function : to insert pet
 * @param {*} petData
 * @param {*} requestId
 */
PetDAO.prototype.insert = async (petData, requestId) => {

	new LoggerHelper().log("info", requestId, "petData", petData);

	let petName = petData.name.trim();
	let petAge = petData.age;
	let petColour = petData.colour.trim();


	return new Promise((resolve, reject) => {

		var query = " INSERT INTO pets (name, age, colour, created_at, updated_at) VALUES ($1, $2, $3, $4, $5) RETURNING id";

		let createdAt = new Date();
		let updatedAt = new Date();

		try {
			  //retrieving a record from details
			  dbConnectionPool.query(
				query,
				[petName, petAge, petColour, createdAt, updatedAt],
				(err, result) => {

					if(err) {
						reject(err);
					} else {
						resolve(result.rows[0].id);
					}
				});
		} catch (err) {
			reject(err);
		}

	}).catch(function(err) {
		return err;
	});

};


/**
 * @Function : to edit pet whole object
 * @param {*} petData
 * @param {*} requestId
 */
PetDAO.prototype.edit = async (petData, requestId) => {

	new LoggerHelper().log("info", requestId, "petData", petData);

	let petId = petData.id;
	let petName = petData.name.trim();
	let petAge = petData.age;
	let petColour = petData.colour.trim();


	return new Promise((resolve, reject) => {

		var query = " UPDATE pets SET name = $1, age = $2, colour = $3, updated_at = $4 WHERE id = $5 RETURNING id, name, age, colour";

		let updatedAt = new Date();

		try {
			  //retrieving a record from details
			  dbConnectionPool.query(
				query,
				[petName, petAge, petColour, updatedAt, petId],
				(err, result) => {

					if(err) {
						reject(err);
					} else {
						resolve(result.rows[0]);
					}
				});
		} catch (err) {
			reject(err);
		}

	}).catch(function(err) {
		return err;
	});

};

/**
 * @Function : to delete pet
 * @param {*} petData
 * @param {*} requestId
 */
PetDAO.prototype.delete = async (petData, requestId) => {

	new LoggerHelper().log("info", requestId, "petData", petData);

	let petId = petData.id;


	return new Promise((resolve, reject) => {

		var query = " DELETE FROM pets WHERE id = $1 ";

		let updatedAt = new Date();

		try {
			  //retrieving a record from details
			  dbConnectionPool.query(
				query,
				[petId],
				(err, result) => {

					if(err) {
						reject(err);
					} else {
						resolve(result);
					}
				});
		} catch (err) {
			reject(err);
		}

	}).catch(function(err) {
		return err;
	});

};


/**
 * @Function : to count pet by name
 * @param {*} petData
 * @param {*} requestId
 */
PetDAO.prototype.countByName = async (petData, isUpdate, requestId) => {

	new LoggerHelper().log("info", requestId, "petData", petData);
	
	let petName = petData.name.trim();

	return new Promise((resolve, reject) => {

		let count = 0;
		let query = "";

			if (!isUpdate) {
				query = " SELECT COUNT(*) AS total FROM pets WHERE name = $1";

				try {
					//retrieving a record from details
					dbConnectionPool.query(
					query,
					[petName],
					(err, result) => {
	
						if(err) {
							reject(err);
						} else {
							resolve(result.rows[0].total);
						}
					});
				} catch (err) {
					reject(err);
				}
			} else {
				if (isUpdate) {
					let petId = petData.id;

					query = " SELECT COUNT(*) AS total FROM pets WHERE name = $1 AND id != $2";
		
					try {
						//retrieving a record from details
						dbConnectionPool.query(
						query,
						[petName, petId],
						(err, result) => {
		
							if(err) {
								reject(err);
							} else {
								resolve(result.rows[0].total);
							}
						});
				} catch (err) {
					reject(err);
				}
			}
		}

	}).catch(function(err) {
		return err;
	});

};

const getAllData = async (requestId) => {
	new LoggerHelper().log("info", requestId);

	return new Promise(async (resolve, reject) => {
		try {
			var query = "SELECT * FROM pets ORDER BY created_at DESC";

			//retrieving a record from details
			dbConnectionPool.query(query, (err, result, fields) => {

				if (err) {
					new LoggerHelper().log("error", requestId, constant.DB_QUERY_ERROR, err);
					reject(err);
				}

				new LoggerHelper().log("info", requestId, constant.BEFORE_RETURNING_RESULT);
				resolve(result.rows);
			});

		} catch (error) {
			new LoggerHelper().log("error", requestId, constant.INSIDE_CATCH_BLOCK, error);
			reject(error);
		}
	}).catch(function(err) {
		return err;
	});
};

module.exports = PetDAO;