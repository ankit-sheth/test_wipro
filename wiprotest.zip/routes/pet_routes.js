/**
 *  @File : to define all routes, for pets
 *  @Created ON : 24/06/2020
 *  @Author : Ankit Sheth
*/

const serverConfig = require("../config/config.js").serverConfig;
const PetService = require("../services/pet_service");

module.exports = function (app) {
	// for get all pets
	app.get(serverConfig.baseURL + serverConfig.version + "/pets", new PetService().getPets);

	// to create new pet
	app.post(serverConfig.baseURL + serverConfig.version + "/pet", new PetService().createPet);

	// to update pet
	app.put(serverConfig.baseURL + serverConfig.version + "/pet", new PetService().editPet);

	// to delete pet
	app.delete(serverConfig.baseURL + serverConfig.version + "/pet", new PetService().deletePet);
};