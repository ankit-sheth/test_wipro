/**
 *  @File : to apply all business logic for pet module
 *  @Created ON : 24/06/2020
 *  @Author : Ankit Sheth
*/

// all required files
const LoggerHelper = require("../helpers/logger_helper");
const constant = require("../helpers/constant");

//config
const config = require("../config/config");

//dao
const PetDAO = require("../dao/pet_dao");



/**
 * Module code starts
 */
function PetBO() { }

/**
 * @Function : to get all pets
 * @param {*} requestId
 * @return : list of pets / null
 */
PetBO.prototype.getPets = (requestId) => {

	new LoggerHelper().log("debug", requestId, constant.INSIDE_BO);

	return new Promise(async (resolve, reject) => {
		try {
			let Area = config.Area;

			let feedbackRole = "";
			if (Area == "Retailer") {
				feedbackRole = "R";
			} else if (Area == "Distributor") {
				feedbackRole = "D";
			}

			let returnData = await new PetDAO().getAll(requestId);

			new LoggerHelper().log("debug", requestId, constant.SUCCESS_DAO);

			if (null !== returnData) {
				resolve(returnData);
			} else {
				resolve(null);
			}

		} catch (error) {
			new LoggerHelper().log("error", requestId, constant.INSIDE_CATCH_BLOCK, error);

			reject(error);
		}
	}).catch(function(err) {
		return err;
	});
};

/**
 * @Function : to insert the pet
 * @param {*} requestData
 * @param {*} requestId
 * @return : true/false
 */
PetBO.prototype.createPet = (requestData, requestId) => {

	new LoggerHelper().log("debug", requestId, constant.INSIDE_BO);

	return new Promise(async (resolve, reject) => {

		try {			
			//let countByName = await new PetDAO().countByName(requestData, false, requestId);

			let result = await new PetDAO().insert(requestData, requestId);

			resolve(result);

		} catch (err) {
			console.log(err);
			new LoggerHelper().log("info", requestId, "Error in petdata insert");
			resolve(null);
		}

	}).catch(function(err) {
		return err;
	});

};


/**
 * @Function : to update the pet, whole object
 * @param {*} requestData
 * @param {*} requestId
 * @return : true/false
 */
PetBO.prototype.editPet = (requestData, requestId) => {

	new LoggerHelper().log("debug", requestId, constant.INSIDE_BO);

	return new Promise(async (resolve, reject) => {

		try {
			//let countByName = await new PetDAO().countByName(requestData, true, requestId);

			// insert pet into db
			let result = new PetDAO().edit(requestData, requestId);

			resolve(result);

		} catch (err) {
			//console.log(err);
			new LoggerHelper().log("info", requestId, "Error in petdata update");
			resolve(null);
		}

	}).catch(function(err) {
		return err;
	});

};


/**
 * @Function : to delete the pet
 * @param {*} requestData
 * @param {*} requestId
 * @return : true/false
 */
PetBO.prototype.deletePet = (requestData, requestId) => {

	new LoggerHelper().log("debug", requestId, constant.INSIDE_BO);

	return new Promise(async (resolve, reject) => {

		try {

			// insert pet into db
			let result = new PetDAO().delete(requestData, requestId);

			resolve(result);

		} catch (err) {
			//console.log(err);
			new LoggerHelper().log("info", requestId, "Error in petdata delete");
			resolve(null);
		}

	}).catch(function(err) {
		return err;
	});

};

module.exports = PetBO;