
const LoggerHelper = require("../helpers/logger_helper");
const ResponseHandler = require("../helpers/response_handler");

module.exports = function(err, req, res, next) {
	console.log("--middlreware--", ex);
	process.on("unhandledRejection", (ex) => {
		//throw ex;

		new LoggerHelper().log("error", res.requestId, ex, ex.message);
		let responseObject = {
			statusCode: 501,
			message: "Application error"+ " => " + ex.message,
			success: false
		};

		new ResponseHandler().errorHandler(req, res, responseObject);

	});

};