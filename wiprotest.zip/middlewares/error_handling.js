const LoggerHelper = require("../helpers/logger_helper");
//var md = require('mobile-detect');

async function logErrors (err, req, res, next) {
	new LoggerHelper().log("error", req.requestId, "log errors", err.stack);
	next();
}

async function clientErrorHandler (err, req, res, next) {
	new LoggerHelper().log("error", req.requestId, "client error handler", err.stack);
	if (req.xhr) {
		res.status(500).send({ error: "Something failed!" });
	  } else {
		next(err);
	  }
}

async function errorHandler (err, req, res, next) {
	new LoggerHelper().log("error", req.requestId, "errorHandler", err.stack);
	res.status(500);
	res.render("error", { error: err });
}

module.exports = {
	logErrors : logErrors,
	clientErrorHandler : clientErrorHandler,
	errorHandler: errorHandler
};