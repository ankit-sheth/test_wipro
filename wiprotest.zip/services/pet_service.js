/**
 *  @File : to define all services/functions for pet module
 *  @Created ON : 24/06/2020
 *  @Author : Ankit Sheth
*/

// Modules
const HTTPStatus = require("http-status");

//config
const config = require("../config/config");

// Helpers
const constant = require("../helpers/constant");
const ResponseHandler = require("../helpers/response_handler");
const LoggerHelper = require("../helpers/logger_helper");
const validationHelper = require("../helpers/validation_helper");
const PetBO = require("../bo/pet_bo");


// Others - success/exceptions
const petMessages = require("../custom_messages/success_messages");
const petSchemas = require("../schemas/pet_schema");


/* may be for some case this prototype is not required, added just considering all functions are not required at a time, so using prototype can save memory load */
function PetService() { }

/**
 * @Function : to get all pets
 * @param {*} request object
 * @param {*} response object
 * @return : data/false
 */
PetService.prototype.getPets = async (req, res) => {
	new LoggerHelper().log("info", res.requestId, constant.START_OF_EXECUTION);

	try {
		let result = await new PetBO().getPets(req.requestId);

		new LoggerHelper().log("debug", res.requestId, constant.BFORE_CALLING_SUCCESS_HANDELER, null);

		new ResponseHandler().successHandler(req, res, HTTPStatus.OK, result);

	} catch (error) {
		new LoggerHelper().log("error", res.requestId, constant.INSIDE_CATCH_BLOCK, error);
		new ResponseHandler().errorHandler(req, res, error);
	}

};

/**
 * @Function : to create the pet, whole record
 * @param {*} request object
 * @param {*} response object
 * @return : data/false
 */
PetService.prototype.createPet = async (req, res) => {
	new LoggerHelper().log("info", res.requestId, constant.START_OF_EXECUTION);
	try {

		// validate the schema
		await new validationHelper().validate(req, res, petSchemas.insertSchema, req.body, res.requestId);

        let result = {};
        
		let petInsertedId = await new PetBO().createPet(req.body, res.requestId);

		new LoggerHelper().log("debug", res.requestId, constant.BFORE_CALLING_SUCCESS_HANDELER, petInsertedId);

		let data = {"lastInsertedId": petInsertedId};
		new ResponseHandler().successHandler(req, res, HTTPStatus.OK, data, petMessages.addPet);

	} catch (error) {
		new LoggerHelper().log("error", res.requestId, constant.INSIDE_CATCH_BLOCK, error);
		new ResponseHandler().errorHandler(req, res, error);
	}
};

/**
 * @Function : to edit the pet, whole record
 * @param {*} request object
 * @param {*} response object
 * @return : data/false
 */
PetService.prototype.editPet = async (req, res) => {
	new LoggerHelper().log("info", res.requestId, constant.START_OF_EXECUTION);
	try {

		// validate the schema
		//await new validationHelper().validate(req, res, petSchema.updatePassword, req.body, res.requestId);

		let result = {};

		let updateData = await new PetBO().editPet(req.body, res.requestId);

		new LoggerHelper().log("debug", res.requestId, constant.BFORE_CALLING_SUCCESS_HANDELER, updateData);

		new ResponseHandler().successHandler(req, res, HTTPStatus.OK, updateData, petMessages.updatePet);

	} catch (error) {
		new LoggerHelper().log("error", res.requestId, constant.INSIDE_CATCH_BLOCK, error);
		new ResponseHandler().errorHandler(req, res, error);
	}
};

/**
 * @Function : to delete the pet
 * @param {*} request object
 * @param {*} response object
 * @return : data/false
 */
PetService.prototype.deletePet = async (req, res) => {
	new LoggerHelper().log("info", res.requestId, constant.START_OF_EXECUTION);
	try {

		// validate the schema
		//await new validationHelper().validate(req, res, petSchema.updatePassword, req.body, res.requestId);

		let result = {};

		let isPetDeleted = await new PetBO().deletePet(req.body, res.requestId);

		new LoggerHelper().log("debug", res.requestId, constant.BFORE_CALLING_SUCCESS_HANDELER, isPetDeleted);

		new ResponseHandler().successHandler(req, res, HTTPStatus.OK, null, petMessages.updatePet);

	} catch (error) {
		new LoggerHelper().log("error", res.requestId, constant.INSIDE_CATCH_BLOCK, error);
		new ResponseHandler().errorHandler(req, res, error);
	}
};


/**
 * @Function : to update the pet, only sended fields
 * @param {*} request object
 * @param {*} response object
 * @return : data/false
 */
PetService.prototype.updatePet = async (req, res) => {
	new LoggerHelper().log("info", res.requestId, constant.START_OF_EXECUTION);
	try {

		// validate the schema
		//await new validationHelper().validate(req, res, petSchema.updatePassword, req.body, res.requestId);

		let result = {};

		let updateData = await new PetBO().updatePet(req.body, res.requestId);

		new LoggerHelper().log("debug", res.requestId, constant.BFORE_CALLING_SUCCESS_HANDELER, updateData);

		new ResponseHandler().successHandler(req, res, HTTPStatus.OK, updateData, petMessages.updatePet);

	} catch (error) {
		new LoggerHelper().log("error", res.requestId, constant.INSIDE_CATCH_BLOCK, error);
		new ResponseHandler().errorHandler(req, res, error);
	}
};



module.exports = PetService;