let chai = require("chai");
let chaiHttp = require("chai-http");
var should = chai.should();
chai.use(chaiHttp);
let server = require("../index");

var expect  = require("chai").expect;
var request = require("request");

const insertSuccessData = {"name":"test-dog-1", "age":10, "colour":"white"};
const insertFailData = {"name1":"test-dog-1", "age":10, "colour":"white"};

const updateSuccessData = {"name":"test-dog-1", "age":10, "colour":"white"};
const updateFaileData = {"name1":"test-dog-1", "age":10, "colour":"white"};

describe("Pets Test", function(done) {

	it("Get Pets", function(done) {
		request("http://localhost:3000/api/v1/pets", function(error, response, body) {
			expect(response.statusCode).to.equal(200);
			done();
		});
	});

	it("Insert Pets, give statuscode 200 on success", function(done) {

		request({url:"http://localhost:3000/api/v1/pet", method:"POST", json:insertSuccessData}, function(error, response, body) {
			expect(response.statusCode).to.equal(200);
			done();
		});
	});

	it("Insert Pets, give statuscode 500 on failure", function(done) {

		request({url:"http://localhost:3000/api/v1/pet", method:"POST", json:insertFailData}, function(error, response, body) {
			expect(response.statusCode).to.equal(400);
			done();
		});
	});

	it("Update Pets, give statuscode 200 on success, with updated name", function(done) {

		request({url:"http://localhost:3000/api/v1/pet", method:"POST", json:insertSuccessData}, function(error, response, body) {
			let updateId = body.data.lastInsertedId;

			let updateSuccessData = {"id": updateId, "name":"update-name", "age":10, "colour":"black"};
			request({url:"http://localhost:3000/api/v1/pet", method:"PUT", json:updateSuccessData}, function(error, response, body) {

				expect(response.statusCode).to.equal(200);
				expect(body.data.name).to.equal("update-name");
				done();
			});
		});
	});

	it("Delete Pets, give data null on update the same record after delete", function(done) {

		request({url:"http://localhost:3000/api/v1/pet", method:"POST", json:insertSuccessData}, function(error, response, body) {
			let updateId = body.data.lastInsertedId;

			let deleteData = {"id":updateId};
			request({url:"http://localhost:3000/api/v1/pet", method:"DELETE", json:deleteData}, function(error, response, body) {

				let updateSuccessData = {"id": updateId, "name":"update-name", "age":10, "colour":"black"};
				request({url:"http://localhost:3000/api/v1/pet", method:"PUT", json:updateSuccessData}, function(error, response, body) {
					expect(body.data).to.equal(null);
					done();
				});
			});


		});
	});

});