module.exports = {
	"addPet": "ADD_PET_SUCCESS",
	"deletePet": "DELETE_PET_SUCCESS",
	"updatePet": "UPDATE_PET_SUCCESS"
};