
/* @File : to put validation for pet request schema */

let joi = require("joi");

let insertSchema = joi.object().keys({
	name: joi.string().required(),
	age: joi.number().required(),
	colour: joi.string().required(),
});

let updateSchema = joi.object().keys({
	id: joi.number().required(),
	name: joi.string().optional(),
	age: joi.number().optional(),
	colour: joi.string().optional(),
});

let updateOptionalSchema = joi.object().keys({
	id: joi.number().required(),
	name: joi.string().required(),
	age: joi.number().required(),
	colour: joi.string().required(),
});

let deleteSchema = joi.object().keys({
	id: joi.number().required()
});


module.exports = {
	insertSchema: insertSchema,
	updateSchema: updateSchema,
	updateOptionalSchema: updateOptionalSchema,
	deleteSchema: deleteSchema
};