module.exports = {
	START_OF_EXECUTION: "Start of execution",
	INSIDE: "Inside ",
	BFORE_CALLING_SUCCESS_HANDELER: "Before calling success handler",
	INSIDE_CATCH_BLOCK: "Inside catch block",
	BEFORE_RETURNING_FROM_METHOD: "Before returning from method",
	BEFORE_RETURNING_RESULT: "Before returning result",
	APPLICATION_DETAILS_NOT_FOUND: "Application details not found for given application",
	ModalCodeAppName:"Modal Code",
	superAdminValue:1,
	DB_ACTIVE:1,
	INSIDE_BO: "Inside BO",
	SUCCESS_BO: "BO Success completed",
	INSIDE_DAO: "Inside DAO",
	SUCCESS_DAO: "DAO Success completed",
	DB_QUERY_ERROR: "Error in db query execution"
};